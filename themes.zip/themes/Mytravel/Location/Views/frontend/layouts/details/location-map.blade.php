@if($row->map_lat && $row->map_lng)
    <div class="g-location">
        <div class="location-map">
            <div id="map_content"></div>
        </div>
    </div>
@endif
