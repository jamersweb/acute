<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 10/18/2019
 * Time: 3:35 PM
 */
namespace Modules\Layout\Events;

class LayoutEndHead{

}